# last stable: 1.5.5
VERSION='1.5.7'
